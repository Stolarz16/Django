from django import forms
from .models import Transakcja
from datetime import date

class TransakcjaForm(forms.ModelForm):
    class Meta:
        model = Transakcja
        fields = ['kwota', 'data', 'kategoria', 'opis', 'typ']
        widgets = {
            'data': forms.DateInput(attrs={'type': 'date', 'value': date.today().strftime("%Y-%m-%d")}),
        }