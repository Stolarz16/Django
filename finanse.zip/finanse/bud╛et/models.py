from django.db import models

class Kategoria(models.Model):
#    KATEGORIE = (
#        ('Jedzenie', 'Jedzenie'),
#        ('Rozrywka', 'Rozrywka'),
#        ('Transport', 'Transport'),
#    )
#    nazwa = models.CharField(max_length=100, choices=KATEGORIE)
    nazwa = models.CharField(max_length=100)

    def __str__(self):
        return self.nazwa

class Transakcja(models.Model):
    TYPY_TRANSAKCJI = (
        ('Przychód', 'Przychód'),
        ('Wydatek', 'Wydatek'),
    )
    KATEGORIE = (
        ('Jedzenie', 'Jedzenie'),
        ('Rozrywka', 'Rozrywka'),
        ('Transport', 'Transport'),
    )
    kwota = models.DecimalField(max_digits=10, decimal_places=2)
    data = models.DateField()
#    kategoria = models.ForeignKey(Kategoria, on_delete=models.CASCADE)
    kategoria = models.CharField(max_length=100, choices=KATEGORIE)
    opis = models.TextField(blank=True)
    typ = models.CharField(max_length=10, choices=TYPY_TRANSAKCJI)

    def __str__(self):
        return f"{self.typ} - {self.kwota} PLN"
