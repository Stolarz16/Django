from django.urls import path
from . import views

urlpatterns = [
    path('', views.lista_transakcji, name='lista_transakcji'),
    path('dodaj/', views.dodaj_transakcje, name='dodaj_transakcje'),
    path('edytuj/<int:pk>/', views.edytuj_transakcje, name='edytuj_transakcje'),
    path('usun/<int:pk>/', views.usun_transakcje, name='usun_transakcje'),
]
