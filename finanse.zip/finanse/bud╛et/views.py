from django.shortcuts import render
from django.shortcuts import render, get_object_or_404, redirect
from .models import Transakcja, Kategoria
from .forms import TransakcjaForm
from django.db.models import Sum

def lista_transakcji(request):
    transakcje = Transakcja.objects.all()
    kategorie_sumy = Transakcja.objects.values('kategoria').annotate(suma=Sum('kwota'))
    
    
    return render(request, 'budżet/lista_transakcji.html', {'transakcje': transakcje,'kategorie_sumy': kategorie_sumy})

def dodaj_transakcje(request):
    if request.method == 'POST':
        form = TransakcjaForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('lista_transakcji')
    else:
        form = TransakcjaForm()
    return render(request, 'budżet/dodaj_transakcje.html', {'form': form})

def edytuj_transakcje(request, pk):
    transakcja = get_object_or_404(Transakcja, pk=pk)
    if request.method == 'POST':
        form = TransakcjaForm(request.POST, instance=transakcja)
        if form.is_valid():
            form.save()
            return redirect('lista_transakcji')
    else:
        form = TransakcjaForm(instance=transakcja)
    return render(request, 'budżet/dodaj_transakcje.html', {'form': form})

def usun_transakcje(request, pk):
    transakcja = get_object_or_404(Transakcja, pk=pk)
    transakcja.delete()
    return redirect('lista_transakcji')
